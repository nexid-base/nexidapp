import React from 'react';
import styles from '../Analysis/Analysis.modules.css';

/**
 * Analysis Component
 * 
 * This component displays the analysis results for a given address,
 * including significant token holdings, NFT collections, and transaction analysis.
 * 
 * @param {Object} props
 * @param {Object} props.data - The analysis data object
 * @param {Array} props.data.tokenAnalysis - Array of significant token holdings
 * @param {Object} props.data.nftAnalysis - Object containing NFT collection data
 * @param {number} props.data.txCount - Total transaction count
 * @param {string} props.data.userCategory - User category based on transaction count
 */
const Analysis = ({ data }) => {
  return (
    <div className={styles.analysis}>
      {/* Token Holdings Analysis Section */}
      <section className={styles.section}>
        <h3>Significant Token Holdings</h3>
        {data.tokenAnalysis.length > 0 ? (
          <ul className={styles.tokenList}>
            {data.tokenAnalysis.map((token, index) => (
              <li key={index} className={styles.tokenItem}>
                <span className={styles.tokenName}>{token.name}:</span>
                <span className={styles.tokenPercentage}>{token.percentage}% of total supply</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className={styles.noData}>No significant token holdings found.</p>
        )}
      </section>

      {/* NFT Collections Analysis Section */}
      <section className={styles.section}>
        <h3>NFT Collections</h3>
        {Object.keys(data.nftAnalysis).length > 0 ? (
          <ul className={styles.nftList}>
            {Object.entries(data.nftAnalysis).map(([collection, count]) => (
              <li key={collection} className={styles.nftItem}>
                <span className={styles.nftName}>{collection}:</span>
                <span className={styles.nftCount}>{count} NFTs</span>
              </li>
            ))}
          </ul>
        ) : (
          <p className={styles.noData}>No NFT collections found.</p>
        )}
      </section>

      {/* Transaction Analysis Section */}
      <section className={styles.section}>
        <h3>Transaction Analysis</h3>
        <p className={styles.txCount}>
          <span className={styles.label}>Transaction Count:</span>
          <span className={styles.value}>{data.txCount}</span>
        </p>
        <p className={styles.userCategory}>
          <span className={styles.label}>User Category:</span>
          <span className={styles.value}>{data.userCategory}</span>
        </p>
      </section>
    </div>
  );
};

export default Analysis;