import React, { useState } from 'react';
import AddressInfo from '../AddressInfo/AddressInfo';
import TokenBalances from '../TokenBalances/TokenBalances';
import NFTs from '../NFTs/NFTs';
import Analysis from '../../components/Analysis/Analysis';
import styles from '../../components/Report/Report.modules.css';

function Report({ data, analysisData }) {
  const [activeSection, setActiveSection] = useState('address');

  const toggleSection = (section) => {
    setActiveSection(activeSection === section ? null : section);
  };

  return (
    <div className={styles.report}>
      <div className={`${styles.section} ${activeSection === 'address' ? styles.active : ''}`}>
        <h2 onClick={() => toggleSection('address')}>Address Information</h2>
        {activeSection === 'address' && <AddressInfo data={data} />}
      </div>

      <div className={`${styles.section} ${activeSection === 'tokens' ? styles.active : ''}`}>
        <h2 onClick={() => toggleSection('tokens')}>Token Balances</h2>
        {activeSection === 'tokens' && <TokenBalances tokens={data.tokens} />}
      </div>

      <div className={`${styles.section} ${activeSection === 'nfts' ? styles.active : ''}`}>
        <h2 onClick={() => toggleSection('nfts')}>NFTs</h2>
        {activeSection === 'nfts' && <NFTs nfts={data.nfts} />}
      </div>

      <div className={`${styles.section} ${activeSection === 'analysis' ? styles.active : ''}`}>
        <h2 onClick={() => toggleSection('analysis')}>Analysis</h2>
        {activeSection === 'analysis' && analysisData && <Analysis data={analysisData} />}
      </div>
    </div>
  );
}

export default Report;