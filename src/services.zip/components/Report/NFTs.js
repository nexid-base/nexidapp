import React from 'react';
import styles from './Report.module.css';

const NFTs = ({ nfts }) => {
  const createBasescanUrl = (address) => `https://basescan.org/address/${address}`;
  const createBasescanTokenUrl = (contractAddress, tokenId) => 
    `https://basescan.org/token/${contractAddress}?a=${tokenId}`;

  return (
    <div className={styles.nftList}>
      {nfts && nfts.length > 0 ? (
        nfts.map((nft, index) => (
          <div key={index} className={styles.nftItem}>
            <img
              src={nft.image?.gateway || nft.media?.[0]?.gateway || '/placeholder-nft.png'}
              alt={nft.title || 'NFT'}
              className={styles.nftImage}
              onError={(e) => { e.target.onerror = null; e.target.src = '/placeholder-nft.png'; }}
            />
            <p><strong>{nft.title || 'Unnamed NFT'}</strong></p>
            <p>
              Token ID:{' '}
              <a href={createBasescanTokenUrl(nft.contract.address, nft.tokenId)} target="_blank" rel="noopener noreferrer">
                {`${nft.tokenId.slice(0, 6)}...${nft.tokenId.slice(-4)}`}
              </a>
            </p>
            <p>
              Contract:{' '}
              <a href={createBasescanUrl(nft.contract.address)} target="_blank" rel="noopener noreferrer">
                {`${nft.contract.address.slice(0, 6)}...${nft.contract.address.slice(-4)}`}
              </a>
            </p>
          </div>
        ))
      ) : (
        <p>No NFTs found</p>
      )}
    </div>
  );
};

export default NFTs;