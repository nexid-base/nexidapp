import React from 'react';
import styles from './Report.module.css';

const TokenBalances = ({ tokens }) => {
  const createBasescanUrl = (address) => `https://basescan.org/address/${address}`;

  return (
    <div className={styles.tokenList}>
      {tokens && tokens.length > 0 ? (
        tokens.map((token, index) => (
          <div key={index} className={styles.tokenItem}>
            {token.metadata.logo && (
              <img src={token.metadata.logo} alt={`${token.metadata.name} logo`} className={styles.tokenLogo} />
            )}
            <div className={styles.tokenInfo}>
              <p><strong>{token.metadata.name} ({token.metadata.symbol})</strong></p>
              <p>Balance: {parseFloat(token.formattedBalance).toFixed(4)}</p>
              <p>
                Address:{' '}
                <a href={createBasescanUrl(token.contractAddress)} target="_blank" rel="noopener noreferrer">
                  {`${token.contractAddress.slice(0, 6)}...${token.contractAddress.slice(-4)}`}
                </a>
              </p>
            </div>
          </div>
        ))
      ) : (
        <p>No tokens found</p>
      )}
    </div>
  );
};

export default TokenBalances;