import React, { useState } from 'react';
import styles from './BasenameSearch.module.css';

const BasenameSearch = ({ onSearch }) => {
  const [searchInput, setSearchInput] = useState('');

  const handleSearch = async () => {
    if (searchInput.trim() === '') {
      console.log('Empty search input');
      return;
    }

    try {
      // First, try to resolve as a Basename
      const response = await fetch(`https://api.onchainsummer.xyz/v1/aliases/${searchInput}`);
      if (response.ok) {
        const data = await response.json();
        if (data && data.address) {
          onSearch(data.address);
          return;
        }
      }

      // If not a Basename, assume it's an Ethereum address
      onSearch(searchInput);
    } catch (error) {
      console.error('Error searching:', error);
      // Handle error (e.g., show error message to user)
    }
  };

  return (
    <div className={styles.basenameSearch}>
      <input
        type="text"
        value={searchInput}
        onChange={(e) => setSearchInput(e.target.value)}
        placeholder="Enter Basename or address"
        className={styles.searchInput}
      />
      <button onClick={handleSearch} className={styles.searchButton}>Search</button>
    </div>
  );
};

export default BasenameSearch;