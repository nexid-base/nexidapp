import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import WalletConnection from './WalletConnection/WalletConnection';
import BasenameSearch from './BasenameSearch';
import Report from './Report/Report';
import ThemeToggle from './ThemeToggle/ThemeToggle';
import { fetchIdentityReport } from '../services/api';
import useAsync from '../hooks/useAsync';
import styles from './HomePage.module.css';

const HomePage = () => {
  const [currentAccount, setCurrentAccount] = useState(null);
  const [reportData, setReportData] = useState(null);
  const navigate = useNavigate();

  const { execute: fetchReport, loading, error } = useAsync(fetchIdentityReport);

  const handleSearch = async (address) => {
    try {
      const data = await fetchReport(address);
      setReportData(data);
    } catch (err) {
      console.error('Error fetching report:', err);
    }
  };

  const handleExport = () => {
    if (reportData) {
      navigate('/export', { state: { reportData } });
    }
  };

  return (
    <div className={styles.homepage}>
      <header className={styles.header}>
        <div className={styles.headerLeft}>
          <img src="/nexid-logo-small.png" alt="NexID Logo" />
          <h1>NexID - Base Identity Report</h1>
        </div>
        <ThemeToggle />
      </header>

      <WalletConnection
        currentAccount={currentAccount}
        setCurrentAccount={setCurrentAccount}
      />

      <BasenameSearch onSearch={handleSearch} />

      {loading && <p>Loading...</p>}
      {error && <p className="error-message">Error: {error.message}</p>}

      {reportData && (
        <>
          <Report data={reportData} />
          <button onClick={handleExport}>Export Report</button>
        </>
      )}

      <footer className={styles.footer}>
        <img src="/nexid-logo-small.png" alt="NexID Logo" className={styles.footerLogo} />
        <p>&copy; nexid-base, all rights reserved.</p>
        <p>Support/donations: 0x9EE9a6Ef0473D8c836448C8494F2983ABC856764</p>
      </footer>
    </div>
  );
};

export default HomePage;