import React from 'react';
import { Link } from 'react-router-dom';
import styles from './ExportPage.module.css';

const ExportPage = ({ reportData }) => {
  const downloadReport = () => {
    const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(JSON.stringify(reportData, null, 2));
    const downloadAnchorNode = document.createElement('a');
    downloadAnchorNode.setAttribute("href", dataStr);
    downloadAnchorNode.setAttribute("download", "base_identity_report.json");
    document.body.appendChild(downloadAnchorNode);
    downloadAnchorNode.click();
    downloadAnchorNode.remove();
  };

  return (
    <div className={styles.exportPage}>
      <h1>Export Report</h1>
      {reportData ? (
        <>
          <p>Your report is ready for export.</p>
          <button onClick={downloadReport} className={styles.exportButton}>Download JSON</button>
        </>
      ) : (
        <p>No report data available. Please generate a report first.</p>
      )}
      <Link to="/" className={styles.backLink}>Back to Home</Link>
    </div>
  );
};

export default ExportPage;