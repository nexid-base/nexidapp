import React from 'react';
import { ethers } from 'ethers';
import styles from './AddressInfo.module.css';

const AddressInfo = ({ data }) => {
  const createBasescanUrl = (address) => `https://basescan.org/address/${address}`;

  return (
    <div className={styles.addressInfo}>
      <p>
        <strong>Address:</strong>{' '}
        <a href={createBasescanUrl(data.address)} target="_blank" rel="noopener noreferrer">
          {data.address}
        </a>
      </p>
      <p>
        <strong>ETH Balance:</strong> {ethers.utils.formatEther(data.balance)} ETH
      </p>
      <p>
        <strong>Is Contract:</strong> {data.isContract ? 'Yes' : 'No'}
      </p>
    </div>
  );
};

export default AddressInfo;