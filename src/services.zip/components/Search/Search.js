import React, { useState } from 'react';
import { isValidAddress } from '../../utils/addressUtils';
import styles from './Search.module.css';

const Search = ({ onSearch, currentAccount }) => {
  const [address, setAddress] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e) => {
    e.preventDefault();
    setError('');
    
    const searchAddress = address.trim() || currentAccount;
    
    if (!searchAddress) {
      setError('Please enter an address or connect a wallet.');
      return;
    }

    if (!isValidAddress(searchAddress)) {
      setError('Invalid Ethereum address format.');
      return;
    }

    onSearch(searchAddress);
  };

  return (
    <div className={styles.searchContainer}>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={address}
          onChange={(e) => setAddress(e.target.value)}
          placeholder="Enter address or ENS name"
          className={styles.searchInput}
        />
        <button type="submit" className={styles.searchButton}>Search</button>
      </form>
      {error && <p className={styles.errorMessage}>{error}</p>}
      <p className={styles.note}>Note: to lookup your own info, connect wallet and click Search with an empty input field.</p>
    </div>
  );
};

export default Search;