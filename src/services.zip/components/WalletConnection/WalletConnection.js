import React, { useEffect } from 'react';
import { useWeb3React } from '@web3-react/core';
import { metaMask } from '../../web3/connectors';
import styles from './WalletConnection.module.css';

const WalletConnection = () => {
  const { account, isActive, connector } = useWeb3React();
  const [error, setError] = useState(null);

  useEffect(() => {
    const connectWalletOnPageLoad = async () => {
      if (localStorage?.getItem('isWalletConnected') === 'true') {
        try {
          await metaMask.activate();
        } catch (ex) {
          console.error('Failed to connect wallet on page load:', ex);
          handleError(ex);
        }
      }
    };
    connectWalletOnPageLoad();
  }, []);

  const handleError = (ex) => {
    if (ex.name === 'NoEthereumProviderError') {
      setError('MetaMask not installed. Please install MetaMask to use this feature.');
    } else {
      setError('An error occurred while connecting to the wallet.');
    }
  };

  const connectWallet = async () => {
    try {
      await metaMask.activate();
      localStorage.setItem('isWalletConnected', 'true');
      setError(null);
    } catch (ex) {
      console.error('Failed to connect wallet:', ex);
      handleError(ex);
    }
  };

  const disconnectWallet = () => {
    try {
      if (connector?.deactivate) {
        void connector.deactivate();
      } else {
        void connector.resetState();
      }
      localStorage.setItem('isWalletConnected', 'false');
      setError(null);
    } catch (ex) {
      console.error('Failed to disconnect wallet:', ex);
      setError('An error occurred while disconnecting the wallet.');
    }
  };

  return (
    <div className={styles.walletConnection}>
      {isActive ? (
        <div>
          <span>Connected: {account ? `${account.slice(0, 6)}...${account.slice(-4)}` : 'Unknown'}</span>
          <button onClick={disconnectWallet} className={styles.button}>Disconnect</button>
        </div>
      ) : (
        <button onClick={connectWallet} className={styles.button}>Connect Wallet</button>
      )}
      {error && <p className={styles.error}>{error}</p>}
    </div>
  );
};

export default WalletConnection;