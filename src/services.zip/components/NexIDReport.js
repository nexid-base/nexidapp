import React, { useState, useEffect } from 'react';
import { ethers } from 'ethers';

const NexIDReport = () => {
  const [currentAccount, setCurrentAccount] = useState(null);
  const [searchAddress, setSearchAddress] = useState('');
  const [report, setReport] = useState(null);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [analysisResults, setAnalysisResults] = useState(null);

  useEffect(() => {
    if (window.ethereum) {
      window.ethereum.on('accountsChanged', handleAccountsChanged);
      window.ethereum.on('chainChanged', () => window.location.reload());
    }
    return () => {
      if (window.ethereum) {
        window.ethereum.removeListener('accountsChanged', handleAccountsChanged);
        window.ethereum.removeListener('chainChanged', () => {});
      }
    };
  }, []);

  const handleAccountsChanged = (accounts) => {
    if (accounts.length === 0) {
      setCurrentAccount(null);
    } else if (accounts[0] !== currentAccount) {
      setCurrentAccount(accounts[0]);
    }
  };

  const connectWallet = async () => {
    try {
      if (typeof window.ethereum !== 'undefined') {
        const accounts = await window.ethereum.request({ method: 'eth_requestAccounts' });
        setCurrentAccount(accounts[0]);
      } else {
        setError('MetaMask is not installed. Please install it to use this feature.');
      }
    } catch (error) {
      setError(`Failed to connect wallet: ${error.message}`);
    }
  };

  const disconnectWallet = () => {
    setCurrentAccount(null);
  };

  const handleSearch = async () => {
    setError('');
    setLoading(true);
    setReport(null);
    setAnalysisResults(null);
    const addressToSearch = searchAddress.trim() || currentAccount;

    if (!addressToSearch) {
      setError('Please enter an address or connect a wallet.');
      setLoading(false);
      return;
    }

    try {
      const response = await fetch(`/api/identity?address=${encodeURIComponent(addressToSearch)}`);
      if (!response.ok) {
        const errorText = await response.text();
        throw new Error(`Network response was not ok: ${response.status} ${response.statusText}\n${errorText}`);
      }
      const data = await response.json();
      setReport(data);
    } catch (error) {
      console.error('Error:', error);
      setError(`Failed to fetch identity report: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const performAnalysis = async () => {
    if (!report) return;

    setLoading(true);
    try {
      const tokenAnalysis = await analyzeTokenHoldings(report.tokens);
      const nftCollections = analyzeNFTCollections(report.nfts);
      const txCount = await getTransactionCount(report.address);
      const userCategory = categorizeUser(txCount);

      setAnalysisResults({ tokenAnalysis, nftCollections, txCount, userCategory });
    } catch (error) {
      console.error('Error performing analysis:', error);
      setError(`Error performing analysis: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const analyzeTokenHoldings = async (tokens) => {
    const significantTokens = [];
    for (const token of tokens) {
      if (parseFloat(token.formattedBalance) === 0) continue;
      try {
        const response = await fetch(`/api/tokensupply?contractAddress=${token.contractAddress}`);
        if (!response.ok) throw new Error(`Failed to fetch total supply: ${response.statusText}`);
        const { totalSupply } = await response.json();
        const percentage = (parseFloat(token.formattedBalance) / parseFloat(ethers.utils.formatUnits(totalSupply, token.metadata.decimals))) * 100;
        if (percentage >= 0.5) {
          significantTokens.push({
            name: token.metadata.name,
            percentage: percentage.toFixed(2)
          });
        }
      } catch (error) {
        console.error(`Error analyzing token ${token.contractAddress}:`, error);
      }
    }
    return significantTokens;
  };

  const analyzeNFTCollections = (nfts) => {
    const collections = {};
    for (const nft of nfts) {
      const collectionName = nft.contract.name || nft.contract.address;
      collections[collectionName] = (collections[collectionName] || 0) + 1;
    }
    return collections;
  };

  const getTransactionCount = async (address) => {
    const response = await fetch(`/api/transactioncount?address=${address}`);
    if (!response.ok) {
      throw new Error(`Failed to fetch transaction count: ${response.statusText}`);
    }
    const data = await response.json();
    return data.txCount;
  };

  const categorizeUser = (txCount) => {
    if (txCount > 10000) return 'Whale';
    if (txCount > 1000) return 'Dolphin';
    if (txCount > 100) return 'Fish';
    if (txCount > 10) return 'Shrimp';
    return 'Plankton';
  };

  const truncateAddress = (address) => {
    return `${address.slice(0, 6)}...${address.slice(-4)}`;
  };

  const createBasescanUrl = (address) => {
    return `https://basescan.org/address/${address}`;
  };

  const createBasescanTokenUrl = (contractAddress, tokenId) => {
    return `https://basescan.org/token/${contractAddress}?a=${tokenId}`;
  };

  const downloadReport = () => {
    if (!report) return;

    const reportData = {
      address: report.address,
      balance: report.balance,
      isContract: report.isContract,
      tokens: report.tokens,
      nfts: report.nfts,
      analysis: analysisResults
    };
    
    const jsonString = JSON.stringify(reportData, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    
    const a = document.createElement('a');
    a.href = url;
    a.download = 'base_identity_report.json';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div>
      <h1>NexID - Base Identity Report</h1>
      <div>
        {currentAccount ? (
          <>
            <p>Connected: {truncateAddress(currentAccount)}</p>
            <button onClick={disconnectWallet}>Disconnect</button>
          </>
        ) : (
          <button onClick={connectWallet}>Connect Wallet</button>
        )}
      </div>
      <div>
        <input
          type="text"
          value={searchAddress}
          onChange={(e) => setSearchAddress(e.target.value)}
          placeholder="Enter address or ENS name"
        />
        <button onClick={handleSearch} disabled={loading}>
          {loading ? 'Searching...' : 'Search'}
        </button>
      </div>
      {error && <p style={{ color: 'red' }}>{error}</p>}
      {report && (
        <div>
          <h2>Report for {report.address}</h2>
          <p>ETH Balance: {ethers.utils.formatEther(report.balance)} ETH</p>
          <p>Is Contract: {report.isContract ? 'Yes' : 'No'}</p>
          <a href={createBasescanUrl(report.address)} target="_blank" rel="noopener noreferrer">
            View on Basescan
          </a>
          
          <h3>Token Balances</h3>
          {report.tokens.length > 0 ? (
            <ul>
              {report.tokens.map((token, index) => (
                <li key={index}>
                  {token.metadata.name} ({token.metadata.symbol}): {parseFloat(token.formattedBalance).toFixed(4)}
                </li>
              ))}
            </ul>
          ) : (
            <p>No tokens found</p>
          )}
          
          <h3>NFTs</h3>
          {report.nfts.length > 0 ? (
            <ul>
              {report.nfts.map((nft, index) => (
                <li key={index}>
                  {nft.title || 'Unnamed NFT'} (ID: {nft.tokenId})
                  <a href={createBasescanTokenUrl(nft.contract.address, nft.tokenId)} target="_blank" rel="noopener noreferrer">
                    View on Basescan
                  </a>
                </li>
              ))}
            </ul>
          ) : (
            <p>No NFTs found</p>
          )}
          
          <button onClick={performAnalysis} disabled={loading}>
            {loading ? 'Analyzing...' : 'Perform Analysis'}
          </button>
          
          {analysisResults && (
            <div>
              <h3>Analysis Results</h3>
              <h4>Significant Token Holdings</h4>
              {analysisResults.tokenAnalysis.length > 0 ? (
                <ul>
                  {analysisResults.tokenAnalysis.map((token, index) => (
                    <li key={index}>{token.name}: {token.percentage}% of total supply</li>
                  ))}
                </ul>
              ) : (
                <p>No significant token holdings found</p>
              )}
              
              <h4>NFT Collections</h4>
              <ul>
                {Object.entries(analysisResults.nftCollections).map(([collection, count]) => (
                  <li key={collection}>{collection}: {count} NFTs</li>
                ))}
              </ul>
              
              <h4>Transaction Analysis</h4>
              <p>Transaction Count: {analysisResults.txCount}</p>
              <p>User Category: {analysisResults.userCategory}</p>
            </div>
          )}
          
          <button onClick={downloadReport}>Download Report</button>
        </div>
      )}
    </div>
  );
};

export default NexIDReport;