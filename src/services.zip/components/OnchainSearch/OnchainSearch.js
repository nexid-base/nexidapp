import React, { useState } from 'react';
import { useWeb3React } from '@web3-react/core';
import { ethers } from 'ethers';
import styles from '../OnchainSearch/OnchainSearch.modules.css';

const OnchainSearch = ({ onSearch }) => {
    const [searchInput, setSearchInput] = useState('');
    const [error, setError] = useState('');
    const { library } = useWeb3React();
  
    const handleSearch = async () => {
      setError('');
      if (!searchInput.trim()) {
        setError('Please enter an address or .base.eth name');
        return;
      }
  
      try {
        let addressToSearch = searchInput.trim();
  
        if (addressToSearch.endsWith('.base.eth')) {
          if (!library) {
            setError('Please connect your wallet to resolve .base.eth names');
            return;
          }
          const resolvedAddress = await library.resolveName(addressToSearch);
          if (!resolvedAddress) {
            setError('Unable to resolve .base.eth name');
            return;
          }
          addressToSearch = resolvedAddress;
        } else if (!ethers.utils.isAddress(addressToSearch)) {
          setError('Invalid address format');
          return;
        }
  
        onSearch(addressToSearch);
      } catch (error) {
        console.error('Error searching:', error);
        setError('An error occurred while searching. Please try again.');
      }
    };
  
    return (
      <div className={styles.onchainSearch}>
        <input
          type="text"
          value={searchInput}
          onChange={(e) => setSearchInput(e.target.value)}
          placeholder="Enter .base.eth name or address"
          className={styles.searchInput}
        />
        <button onClick={handleSearch} className={styles.searchButton}>Search</button>
        {error && <p className={styles.error}>{error}</p>}
      </div>
    );
  };
  
  export default OnchainSearch;