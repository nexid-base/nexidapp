import React from 'react';
import { useTheme } from '../../contexts/ThemeContext';
import styles from './ThemeToggle.module.css';

const ThemeToggle = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className={styles.themeToggle}>
      <label className={styles.switch}>
        <input
          type="checkbox"
          checked={theme === 'dark'}
          onChange={toggleTheme}
        />
        <span className={`${styles.slider} ${styles.round}`}></span>
      </label>
      <span>{theme === 'light' ? 'Light' : 'Dark'} Mode</span>
    </div>
  );
};

export default ThemeToggle;