import { ethers } from 'ethers';

export const truncateAddress = (address) => {
  if (!address) return '';
  return `${address.slice(0, 6)}...${address.slice(-4)}`;
};

export const isValidAddress = (address) => {
  return ethers.utils.isAddress(address);
};

export const createBasescanUrl = (address) => {
  return `https://basescan.org/address/${address}`;
};

export const createBasescanTokenUrl = (contractAddress, tokenId) => {
  return `https://basescan.org/token/${contractAddress}?a=${tokenId}`;
};