export const formatBalance = (balance, decimals = 18, displayDecimals = 4) => {
  if (!balance) return '0';
  const formatted = (parseFloat(balance) / 10 ** decimals).toFixed(displayDecimals);
  return parseFloat(formatted).toString(); // Remove trailing zeros
};

export const formatPercentage = (value, decimals = 2) => {
  return `${parseFloat(value).toFixed(decimals)}%`;
};

export const formatDate = (timestamp) => {
  return new Date(timestamp * 1000).toLocaleString();
};