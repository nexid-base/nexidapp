import { ethers } from 'ethers';

const API_BASE_URL = '/proxy';

export const fetchIdentityReport = async (address) => {
  const response = await fetch(`${API_BASE_URL}/identity?address=${encodeURIComponent(address)}`);
  if (!response.ok) {
    throw new Error(`Network response was not ok: ${response.status} ${response.statusText}`);
  }
  return await response.json();
};

export const analyzeTokenHoldings = async (tokens) => {
  const significantTokens = [];
  for (const token of tokens) {
    if (parseFloat(token.formattedBalance) === 0) continue;
    try {
      const response = await fetch(`${API_BASE_URL}/tokensupply?contractAddress=${token.contractAddress}`);
      if (!response.ok) throw new Error(`Failed to fetch total supply: ${response.statusText}`);
      const { totalSupply } = await response.json();
      const percentage = (parseFloat(token.formattedBalance) / parseFloat(ethers.utils.formatUnits(totalSupply, token.metadata.decimals))) * 100;
      if (percentage >= 0.5) {
        significantTokens.push({
          name: token.metadata.name,
          percentage: percentage.toFixed(2)
        });
      }
    } catch (error) {
      console.error(`Error analyzing token ${token.contractAddress}:`, error);
    }
  }
  return significantTokens;
};

export const analyzeNFTCollections = (nfts) => {
  const collections = {};
  for (const nft of nfts) {
    const collectionName = nft.contract.name || nft.contract.address;
    collections[collectionName] = (collections[collectionName] || 0) + 1;
  }
  return collections;
};

export const getTransactionCount = async (address) => {
  const response = await fetch(`${API_BASE_URL}/transactioncount?address=${address}`);
  if (!response.ok) {
    throw new Error(`Failed to fetch transaction count: ${response.statusText}`);
  }
  const data = await response.json();
  return data.txCount;
};

export const categorizeUser = (txCount) => {
  if (txCount > 10000) return 'Whale';
  if (txCount > 1000) return 'Dolphin';
  if (txCount > 100) return 'Fish';
  if (txCount > 10) return 'Shrimp';
  return 'Plankton';
};