import { ethers } from 'ethers';

export const connectWallet = async () => {
  if (typeof window.ethereum !== 'undefined') {
    try {
      const provider = new ethers.providers.Web3Provider(window.ethereum);
      await provider.send("eth_requestAccounts", []);
      const signer = provider.getSigner();
      const address = await signer.getAddress();
      return { provider, signer, address };
    } catch (error) {
      console.error('Failed to connect wallet:', error);
      throw error;
    }
  } else {
    throw new Error('MetaMask is not installed');
  }
};

export const getENSName = async (address) => {
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  try {
    const name = await provider.lookupAddress(address);
    return name || null;
  } catch (error) {
    console.error('Error fetching ENS name:', error);
    return null;
  }
};

export const resolveENS = async (ensName) => {
  const provider = new ethers.providers.JsonRpcProvider('https://mainnet.base.org');
  try {
    const address = await provider.resolveName(ensName);
    return address || null;
  } catch (error) {
    console.error('Error resolving ENS name:', error);
    return null;
  }
};