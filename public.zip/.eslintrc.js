module.exports = {
  extends: ['react-app', 'react-app/jest'],
  rules: {
    'no-undef': 'off', // This will turn off the no-undef rule for BigInt
  },
  globals: {
    BigInt: 'readonly', // This will tell ESLint that BigInt is a global readonly variable
  },
};